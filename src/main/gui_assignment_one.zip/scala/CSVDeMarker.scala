import java.io.File
import scala.io.{Codec, Source}

/**
  * removes markup from csv.
  */
object CSVDeMarker extends App {
  val origFile = getClass.getResource("CSC212-16F_2.csv")

  val file = new File(origFile.getPath)

  val correctedLines = Source.fromURL(origFile)(Codec.UTF8).getLines().map((line) => {
    line.filter((d) => d.isLetterOrDigit || d.isSpaceChar || d == ',')
  }).toList

  println(correctedLines.filterNot(_ == correctedLines.last).mkString("\n"))

}
